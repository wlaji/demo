<?
header("Location: http://www.csszengarden.com/?cssfile=026/026.css");
?>
