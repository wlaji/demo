<?
header("Location: http://www.csszengarden.com/?cssfile=041/041.css");
?>
