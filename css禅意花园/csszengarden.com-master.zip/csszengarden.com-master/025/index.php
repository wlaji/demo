<?
header("Location: http://www.csszengarden.com/?cssfile=025/025.css");
?>
