<?
header("Location: http://www.csszengarden.com/?cssfile=005/005.css");
?>
