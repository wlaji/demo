<?
header("Location: http://www.csszengarden.com/?cssfile=097/097.css");
?>
