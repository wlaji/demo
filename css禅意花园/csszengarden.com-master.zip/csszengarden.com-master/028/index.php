<?
header("Location: http://www.csszengarden.com/?cssfile=028/028.css");
?>
