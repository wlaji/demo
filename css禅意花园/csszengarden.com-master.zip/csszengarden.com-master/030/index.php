<?
header("Location: http://www.csszengarden.com/?cssfile=030/030.css");
?>
