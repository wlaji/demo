<?
header("Location: http://www.csszengarden.com/?cssfile=058/058.css");
?>
