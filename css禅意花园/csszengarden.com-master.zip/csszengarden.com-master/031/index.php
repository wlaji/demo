<?
header("Location: http://www.csszengarden.com/?cssfile=031/031.css");
?>
