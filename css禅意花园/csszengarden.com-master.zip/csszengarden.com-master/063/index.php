<?
header("Location: http://www.csszengarden.com/?cssfile=063/063.css");
?>
