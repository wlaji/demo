<?
header("Location: http://www.csszengarden.com/?cssfile=094/094.css");
?>
