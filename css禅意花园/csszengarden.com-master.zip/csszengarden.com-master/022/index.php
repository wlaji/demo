<?
header("Location: http://www.csszengarden.com/?cssfile=022/022.css");
?>
