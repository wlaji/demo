<?
header("Location: http://www.csszengarden.com/?cssfile=068/068.css");
?>
