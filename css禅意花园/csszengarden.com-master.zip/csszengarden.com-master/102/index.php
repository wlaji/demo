<?
header("Location: http://www.csszengarden.com/?cssfile=102/102.css");
?>
