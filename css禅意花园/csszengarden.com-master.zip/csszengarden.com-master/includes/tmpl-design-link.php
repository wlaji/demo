					<li>
						<a href="<?php echo $designURL; ?>" class="design-name"><?php echo $designName; ?></a> <?php echo $i18nBy; ?>
						<a href="<?php echo $designerURL; ?>" class="designer-name"><?php echo $designerName; ?></a>
					</li>